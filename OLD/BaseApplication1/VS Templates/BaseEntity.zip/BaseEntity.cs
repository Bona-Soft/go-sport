﻿using MYB.BaseApplication.Framework.Helpers;
using $rootnamespace$.SubEntities;
using MYB.FaltaUno.Model.Interfaces.Entities;
using MYB.FaltaUno.Model.Interfaces.SubEntities;
using System;
using System.Collections.Generic;

namespace $rootnamespace$
{
	public class $safeitemname$ : Entity, I$safeitemname$
	{
		public key<long> $safeitemname$ID { get; private set; }

		public string Name { get; set; }


		public $safeitemname$(long id)
		{
			$safeitemname$ID = id;
		}

		public $safeitemname$()
		{
			$safeitemname$ID = 0;
		}
	}
}